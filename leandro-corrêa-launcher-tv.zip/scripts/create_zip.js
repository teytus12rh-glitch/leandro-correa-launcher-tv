import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const archiver = require('archiver');

const outputDir = path.resolve('public/downloads');
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

const outputPath = path.join(outputDir, 'LeandroCorreaLauncher-TV.zip');
const output = fs.createWriteStream(outputPath);
const archive = archiver('zip', { zlib: { level: 9 } });

output.on('close', () => {
  console.log(`LeandroCorreaLauncher-TV.zip successfully created (${archive.pointer()} total bytes)`);
});

archive.on('error', (err) => {
  throw err;
});

archive.pipe(output);

// Append files
if (fs.existsSync('dist')) {
  archive.directory('dist/', 'app-build/');
}
if (fs.existsSync('capacitor.config.json')) {
  archive.file('capacitor.config.json', { name: 'capacitor.config.json' });
}
if (fs.existsSync('COMO_GERAR_APK.md')) {
  archive.file('COMO_GERAR_APK.md', { name: 'COMO_GERAR_APK.md' });
}
if (fs.existsSync('public/manifest.json')) {
  archive.file('public/manifest.json', { name: 'manifest.json' });
}

archive.finalize();
