import zipfile
import os

zip_path = 'public/downloads/LeandroCorreaLauncher-TV.zip'
os.makedirs('public/downloads', exist_ok=True)

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    # Add dist files
    for root, dirs, files in os.walk('dist'):
        for file in files:
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, 'dist')
            zipf.write(full_path, os.path.join('app-production', rel_path))
    
    # Add root configs and docs
    if os.path.exists('capacitor.config.json'):
        zipf.write('capacitor.config.json', 'capacitor.config.json')
    if os.path.exists('COMO_GERAR_APK.md'):
        zipf.write('COMO_GERAR_APK.md', 'COMO_GERAR_APK.md')
    if os.path.exists('public/manifest.json'):
        zipf.write('public/manifest.json', 'manifest.json')

print(f"Zip created successfully at {zip_path} ({os.path.getsize(zip_path)} bytes)")
