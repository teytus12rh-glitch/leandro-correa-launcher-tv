import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateNextFocus,
  addFavoriteApp,
  removeFavoriteApp,
  moveFavoriteApp,
  isAppInFavorites,
  formatLauncherTime,
  formatLauncherDate,
  formatLauncherDateSubline
} from './launcherLogic';
import { AppItem, FocusState } from '../types/launcher';

test('formatLauncherTime formats with leading zeros', () => {
  const d = new Date(2026, 8, 27, 9, 5);
  assert.equal(formatLauncherTime(d), '09:05');

  const d2 = new Date(2026, 8, 27, 19, 42);
  assert.equal(formatLauncherTime(d2), '19:42');
});

test('formatLauncherDate formats Portuguese day of week and full date', () => {
  // 2026-09-27 is a Sunday
  const d = new Date(2026, 8, 27);
  const res = formatLauncherDate(d);
  assert.equal(res.dayOfWeek, 'Domingo');
  assert.equal(res.fullDate, '27 de Setembro de 2026');
});

test('formatLauncherDateSubline formats subline string', () => {
  const d = new Date(2026, 8, 27);
  const subline = formatLauncherDateSubline(d);
  assert.equal(subline, 'Ano: 2026  |  Mês: 09  |  Dia: 27');
});

test('calculateNextFocus navigates across zones properly', () => {
  const counts = {
    sidebarCount: 5,
    appsCount: 5,
    hdmiCount: 3,
    mediaCount: 6,
  };

  // From sidebar down
  const initialSidebar: FocusState = { zone: 'sidebar', index: 0 };
  const stepDown = calculateNextFocus(initialSidebar, 'down', counts);
  assert.deepEqual(stepDown, { zone: 'sidebar', index: 1 });

  // From sidebar right to apps
  const stepRight = calculateNextFocus(initialSidebar, 'right', counts);
  assert.deepEqual(stepRight, { zone: 'apps', index: 0 });

  // From apps down to hdmi
  const appFocus: FocusState = { zone: 'apps', index: 1 };
  const appDown = calculateNextFocus(appFocus, 'down', counts);
  assert.equal(appDown.zone, 'hdmi');

  // From apps left to sidebar
  const appLeft = calculateNextFocus({ zone: 'apps', index: 0 }, 'left', counts);
  assert.deepEqual(appLeft, { zone: 'sidebar', index: 0 });
});

test('favorites management adds and removes apps correctly', () => {
  const initialApps: AppItem[] = [
    { id: 'app1', name: 'App 1', category: 'Cat 1', iconType: 'custom' },
    { id: 'app2', name: 'App 2', category: 'Cat 2', iconType: 'custom' },
    { id: 'add_fav', name: '+ Favorito', category: 'Personalizar', iconType: 'add' },
  ];

  const newApp: AppItem = { id: 'netflix', name: 'Netflix', category: 'Streaming', iconType: 'netflix' };

  // Add app
  const updated = addFavoriteApp(initialApps, newApp);
  assert.equal(updated.length, 4);
  assert.equal(updated[2].id, 'netflix'); // Inserted before + Favorito
  assert.equal(updated[3].id, 'add_fav');

  // Check presence
  assert.equal(isAppInFavorites(updated, 'netflix'), true);
  assert.equal(isAppInFavorites(updated, 'spotify'), false);

  // Remove app
  const removed = removeFavoriteApp(updated, 'app1');
  assert.equal(removed.length, 3);
  assert.equal(isAppInFavorites(removed, 'app1'), false);

  // Move app
  const moved = moveFavoriteApp(removed, 0, 1);
  assert.equal(moved[0].id, 'netflix');
  assert.equal(moved[1].id, 'app2');
});
