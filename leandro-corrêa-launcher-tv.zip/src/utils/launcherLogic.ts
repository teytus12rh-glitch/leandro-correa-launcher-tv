import { AppItem, FocusState, FocusZone } from '../types/launcher';

export const DAYS_PT = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
export const MONTHS_PT = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];

/**
 * Formats time as HH:mm
 */
export function formatLauncherTime(date: Date): string {
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  return `${hours}:${minutes}`;
}

/**
 * Formats date as e.g. "Sábado" and "27 de Setembro de 2026"
 */
export function formatLauncherDate(date: Date, isPhotoMode: boolean = false): { dayOfWeek: string; fullDate: string } {
  const dayOfWeek = isPhotoMode ? 'Sábado' : DAYS_PT[date.getDay()];
  const day = date.getDate();
  const month = MONTHS_PT[date.getMonth()];
  const year = date.getFullYear();

  return {
    dayOfWeek,
    fullDate: `${day} de ${month} de ${year}`,
  };
}

/**
 * Formats subline as "Ano: 2026 | Mês: 09 | Dia: 27"
 */
export function formatLauncherDateSubline(date: Date): string {
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const day = date.getDate().toString().padStart(2, '0');
  return `Ano: ${year}  |  Mês: ${month}  |  Dia: ${day}`;
}

/**
 * Spatial navigation handler for D-Pad
 */
export function calculateNextFocus(
  current: FocusState,
  direction: 'up' | 'down' | 'left' | 'right',
  counts: {
    sidebarCount: number;
    appsCount: number;
    hdmiCount: number;
    mediaCount: number;
  }
): FocusState {
  const { zone, index } = current;

  if (zone === 'sidebar') {
    if (direction === 'up') {
      return { zone: 'sidebar', index: Math.max(0, index - 1) };
    }
    if (direction === 'down') {
      return { zone: 'sidebar', index: Math.min(counts.sidebarCount - 1, index + 1) };
    }
    if (direction === 'right') {
      // Move from sidebar into main content area
      if (index === 0) return { zone: 'apps', index: 0 };
      if (index === 1 || index === 2) return { zone: 'media', index: 0 };
      if (index === 3) return { zone: 'apps', index: 0 };
      if (index === 4) return { zone: 'weather', index: 0 };
      return { zone: 'apps', index: 0 };
    }
    return current;
  }

  if (zone === 'weather') {
    if (direction === 'down') {
      return { zone: 'apps', index: 0 };
    }
    if (direction === 'left') {
      return { zone: 'sidebar', index: 0 };
    }
    return current;
  }

  if (zone === 'apps') {
    if (direction === 'left') {
      if (index > 0) {
        return { zone: 'apps', index: index - 1 };
      }
      return { zone: 'sidebar', index: 0 };
    }
    if (direction === 'right') {
      return { zone: 'apps', index: Math.min(counts.appsCount - 1, index + 1) };
    }
    if (direction === 'up') {
      return { zone: 'weather', index: 0 };
    }
    if (direction === 'down') {
      return { zone: 'hdmi', index: Math.min(counts.hdmiCount - 1, Math.floor((index / counts.appsCount) * counts.hdmiCount)) };
    }
  }

  if (zone === 'hdmi') {
    if (direction === 'left') {
      if (index > 0) {
        return { zone: 'hdmi', index: index - 1 };
      }
      return { zone: 'sidebar', index: 0 };
    }
    if (direction === 'right') {
      return { zone: 'hdmi', index: Math.min(counts.hdmiCount - 1, index + 1) };
    }
    if (direction === 'up') {
      return { zone: 'apps', index: Math.min(counts.appsCount - 1, Math.floor((index / counts.hdmiCount) * counts.appsCount)) };
    }
    if (direction === 'down') {
      return { zone: 'media', index: Math.min(counts.mediaCount - 1, Math.floor((index / counts.hdmiCount) * counts.mediaCount)) };
    }
  }

  if (zone === 'media') {
    if (direction === 'left') {
      if (index > 0) {
        return { zone: 'media', index: index - 1 };
      }
      return { zone: 'sidebar', index: 1 };
    }
    if (direction === 'right') {
      return { zone: 'media', index: Math.min(counts.mediaCount - 1, index + 1) };
    }
    if (direction === 'up') {
      return { zone: 'hdmi', index: Math.min(counts.hdmiCount - 1, Math.floor((index / counts.mediaCount) * counts.hdmiCount)) };
    }
  }

  return current;
}

/**
 * Pure functions for favorites management
 */
export function addFavoriteApp(apps: AppItem[], newApp: AppItem): AppItem[] {
  if (apps.some(a => a.id === newApp.id)) {
    return apps;
  }
  // Keep '+ Favorito' at the end if it exists
  const addBtnIndex = apps.findIndex(a => a.id === 'add_fav');
  if (addBtnIndex !== -1) {
    const list = [...apps];
    list.splice(addBtnIndex, 0, newApp);
    return list;
  }
  return [...apps, newApp];
}

export function removeFavoriteApp(apps: AppItem[], appId: string): AppItem[] {
  // Prevent removing '+ Favorito' or 'more_apps'
  if (appId === 'add_fav') return apps;
  return apps.filter(a => a.id !== appId);
}

export function moveFavoriteApp(apps: AppItem[], fromIndex: number, toIndex: number): AppItem[] {
  if (fromIndex < 0 || fromIndex >= apps.length || toIndex < 0 || toIndex >= apps.length) {
    return apps;
  }
  const result = [...apps];
  const [removed] = result.splice(fromIndex, 1);
  result.splice(toIndex, 0, removed);
  return result;
}

export function isAppInFavorites(apps: AppItem[], appId: string): boolean {
  return apps.some(a => a.id === appId);
}
