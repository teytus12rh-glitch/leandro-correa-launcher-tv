import React from 'react';
import { X, Volume2, VolumeX, Sparkles, Tv, ShieldCheck, MapPin, Clock, Star, Download, Smartphone } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  ambientGlow: boolean;
  onToggleAmbientGlow: () => void;
  oledProtection: boolean;
  onToggleOledProtection: () => void;
  isSimulatedTime: boolean;
  onToggleTimeMode: () => void;
  city: string;
  onCityChange: (newCity: string) => void;
  onOpenCreator: () => void;
  onOpenFavoritesManager: () => void;
  onOpenApkGuide: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  soundEnabled,
  onToggleSound,
  ambientGlow,
  onToggleAmbientGlow,
  oledProtection,
  onToggleOledProtection,
  isSimulatedTime,
  onToggleTimeMode,
  city,
  onCityChange,
  onOpenCreator,
  onOpenFavoritesManager,
  onOpenApkGuide,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in select-none">
      <div className="relative w-full max-w-2xl bg-slate-900 border-2 border-cyan-500/60 rounded-3xl p-6 sm:p-8 shadow-[0_0_50px_rgba(6,182,212,0.35)] overflow-y-auto max-h-[90vh]">
        {/* Close Button */}
        <button
          onClick={() => {
            soundEngine.playBackSound();
            onClose();
          }}
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="pb-4 border-b border-slate-800">
          <h3 className="text-2xl font-bold text-white flex items-center gap-2.5">
            <Tv className="w-6 h-6 text-cyan-400" />
            <span>Configurações do Launcher</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Personalize sons, imagem, tela inicial e recursos da sua TCL OLED 55 e Mi Stick
          </p>
        </div>

        {/* Quick Access Tiles */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-5">
          <button
            onClick={() => {
              soundEngine.playSelectSound();
              onOpenCreator();
            }}
            className="p-3.5 rounded-2xl bg-slate-800/80 hover:bg-cyan-950/40 border border-cyan-500/40 flex flex-col items-center text-center transition-all cursor-pointer group"
          >
            <Sparkles className="w-5 h-5 text-cyan-400 mb-1.5 group-hover:scale-110 transition-transform" />
            <span className="text-xs font-bold text-white">Criador Leandro Corrêa</span>
            <span className="text-[10px] text-cyan-300 mt-0.5">Ver créditos oficiais</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playSelectSound();
              onOpenFavoritesManager();
            }}
            className="p-3.5 rounded-2xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 flex flex-col items-center text-center transition-all cursor-pointer group"
          >
            <Star className="w-5 h-5 text-amber-400 mb-1.5 group-hover:scale-110 transition-transform" />
            <span className="text-xs font-bold text-white">Favoritos na Tela</span>
            <span className="text-[10px] text-slate-400 mt-0.5">Incluir / Excluir apps</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playSelectSound();
              onOpenApkGuide();
            }}
            className="p-3.5 rounded-2xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 flex flex-col items-center text-center transition-all cursor-pointer group"
          >
            <Download className="w-5 h-5 text-emerald-400 mb-1.5 group-hover:scale-110 transition-transform" />
            <span className="text-xs font-bold text-white">Instalar APK na TV</span>
            <span className="text-[10px] text-slate-400 mt-0.5">TCL & Mi Stick</span>
          </button>
        </div>

        {/* Settings List */}
        <div className="space-y-4 text-sm text-slate-300">
          {/* Sound FX Toggle */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-800/50 border border-slate-700/50">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
                {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
              </div>
              <div>
                <span className="font-bold text-white block">Sons Modernos de Navegação</span>
                <span className="text-xs text-slate-400">Efeitos sonoros futuristas sintetizados ao navegar com o controle</span>
              </div>
            </div>
            <button
              onClick={() => {
                onToggleSound();
                if (!soundEnabled) soundEngine.playSelectSound();
              }}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                soundEnabled ? 'bg-cyan-500' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform transform absolute top-0.5 ${
                  soundEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Ambient Glow */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-800/50 border border-slate-700/50">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-blue-500/10 text-blue-400">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <span className="font-bold text-white block">Iluminação Ambiente Traseira (Ambilight)</span>
                <span className="text-xs text-slate-400">Brilho suave azul/ciano atrás dos elementos para TVs OLED</span>
              </div>
            </div>
            <button
              onClick={() => {
                soundEngine.playFocusTick();
                onToggleAmbientGlow();
              }}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                ambientGlow ? 'bg-cyan-500' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform transform absolute top-0.5 ${
                  ambientGlow ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* OLED Anti-Burn-In Protection */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-800/50 border border-slate-700/50">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <span className="font-bold text-white block">Proteção TCL OLED 55" (Anti-Burn-In)</span>
                <span className="text-xs text-slate-400">Preto puro absoluto (#000000) e desfoque protetor de pixels</span>
              </div>
            </div>
            <button
              onClick={() => {
                soundEngine.playFocusTick();
                onToggleOledProtection();
              }}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                oledProtection ? 'bg-emerald-500' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform transform absolute top-0.5 ${
                  oledProtection ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Time Mode Toggle */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-800/50 border border-slate-700/50">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <span className="font-bold text-white block">Modo do Relógio</span>
                <span className="text-xs text-slate-400">
                  {isSimulatedTime ? 'Exibindo 19:42 • 27 de Setembro de 2026 (Foto Exata)' : 'Exibindo Hora e Data em Tempo Real'}
                </span>
              </div>
            </div>
            <button
              onClick={() => {
                soundEngine.playFocusTick();
                onToggleTimeMode();
              }}
              className="px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-xs font-semibold cursor-pointer"
            >
              {isSimulatedTime ? 'Usar Hora Real' : 'Usar Modo Foto'}
            </button>
          </div>

          {/* Weather Location Input */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-800/50 border border-slate-700/50">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <span className="font-bold text-white block">Localização do Clima</span>
                <span className="text-xs text-slate-400">Cidade atual do painel de previsão</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={city}
                onChange={(e) => onCityChange(e.target.value)}
                className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-white text-xs w-36 focus:outline-none focus:border-cyan-400"
                placeholder="Ex: Jacarezinho"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-5 mt-5 border-t border-slate-800 flex justify-end">
          <button
            onClick={() => {
              soundEngine.playSelectSound();
              onClose();
            }}
            className="px-6 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm shadow-[0_0_15px_rgba(6,182,212,0.4)] cursor-pointer"
          >
            Salvar e Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
