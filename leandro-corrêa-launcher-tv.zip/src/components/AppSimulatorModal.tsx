import React from 'react';
import { X, Play, Tv, ArrowLeft, Volume2, ShieldCheck, Film } from 'lucide-react';
import { soundEngine } from '../utils/audio';
import { AppItem, MediaItem, HdmiSource } from '../types/launcher';

interface AppSimulatorModalProps {
  app?: AppItem | null;
  media?: MediaItem | null;
  hdmi?: HdmiSource | null;
  onClose: () => void;
}

export const AppSimulatorModal: React.FC<AppSimulatorModalProps> = ({
  app,
  media,
  hdmi,
  onClose,
}) => {
  if (!app && !media && !hdmi) return null;

  const title = app?.name || media?.title || hdmi?.name;
  const subtitle = app?.category || media?.type || hdmi?.label;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-lg animate-fade-in select-none">
      <div className="relative w-full max-w-4xl bg-slate-950 border-2 border-cyan-400/80 rounded-3xl p-6 sm:p-8 shadow-[0_0_80px_rgba(6,182,212,0.45)] flex flex-col justify-between min-h-[480px]">
        {/* Top bar */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                soundEngine.playBackSound();
                onClose();
              }}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white hover:border-cyan-400 text-xs font-semibold cursor-pointer transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar ao Launcher (ESC)</span>
            </button>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <Tv className="w-4 h-4 text-cyan-400" />
              <span>TCL OLED 55" • Google TV</span>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playBackSound();
              onClose();
            }}
            className="p-2 rounded-full bg-slate-900 text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Center Simulated Player / Screen */}
        <div className="flex-1 flex flex-col items-center justify-center text-center my-6 p-8 rounded-2xl bg-gradient-to-b from-slate-900/60 to-black/80 border border-slate-800 relative overflow-hidden">
          {media?.backdropUrl && (
            <img
              src={media.backdropUrl}
              alt=""
              className="absolute inset-0 w-full h-full object-cover opacity-20 filter blur-sm"
            />
          )}

          <div className="relative z-10 flex flex-col items-center max-w-lg">
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-[0_0_30px_rgba(6,182,212,0.6)] mb-4">
              {app ? <Tv className="w-10 h-10" /> : media ? <Film className="w-10 h-10" /> : <Play className="w-10 h-10" />}
            </div>

            <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {title}
            </h3>
            <p className="text-sm text-cyan-400 font-semibold mt-1">
              {subtitle}
            </p>

            {media?.synopsis && (
              <p className="text-xs text-slate-300 mt-3 line-clamp-3 leading-relaxed">
                {media.synopsis}
              </p>
            )}

            {hdmi && (
              <div className="mt-4 px-4 py-2 rounded-xl bg-slate-900/90 border border-cyan-500/40 text-xs text-cyan-300">
                Dispositivo Conectado: <strong>{hdmi.connectedDevice || 'Entrada Ativa'}</strong>
              </div>
            )}

            <div className="mt-6 flex items-center gap-3">
              <button
                onClick={() => soundEngine.playSelectSound()}
                className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-sm shadow-[0_0_20px_rgba(6,182,212,0.5)] transition-all cursor-pointer"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>{media ? 'Assistir Agora' : 'Executar no Dispositivo'}</span>
              </button>

              <button
                onClick={() => {
                  soundEngine.playBackSound();
                  onClose();
                }}
                className="px-5 py-3 rounded-2xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white text-sm font-semibold cursor-pointer"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Status bar */}
        <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-800">
          <span>Launcher Oficial • Leandro Corrêa</span>
          <span>4K HDR 60fps • Dolby Atmos</span>
        </div>
      </div>
    </div>
  );
};
