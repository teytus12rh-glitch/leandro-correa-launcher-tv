import React, { useState } from 'react';
import { LayoutGrid, Plus, Trash2, ArrowLeft, ArrowRight, Play, ExternalLink } from 'lucide-react';
import { AppItem } from '../types/launcher';
import { soundEngine } from '../utils/audio';

interface AppRowProps {
  apps: AppItem[];
  isFocusedZone: boolean;
  focusedIndex: number;
  onFocusChange: (index: number) => void;
  onLaunchApp: (app: AppItem) => void;
  onOpenAddModal: () => void;
  onOpenAllApps: () => void;
  onRemoveApp: (appId: string) => void;
  onMoveApp: (fromIndex: number, toIndex: number) => void;
}

export const AppRow: React.FC<AppRowProps> = ({
  apps,
  isFocusedZone,
  focusedIndex,
  onFocusChange,
  onLaunchApp,
  onOpenAddModal,
  onOpenAllApps,
  onRemoveApp,
  onMoveApp,
}) => {
  const [contextMenuAppId, setContextMenuAppId] = useState<string | null>(null);

  const renderAppIcon = (app: AppItem) => {
    switch (app.iconType) {
      case 'flixcine':
        return (
          <div className="flex items-center gap-2">
            <div className="w-0 h-0 border-y-[13px] border-y-transparent border-l-[22px] border-l-red-600 drop-shadow-[0_0_12px_rgba(220,38,38,0.8)]"></div>
            <div className="flex flex-col text-left">
              <span className="text-xl font-black tracking-tight text-white leading-none">
                FLIX<span className="text-red-500">CINE</span>
              </span>
            </div>
          </div>
        );
      case 'youtube':
        return (
          <div className="flex items-center gap-2">
            <div className="w-10 h-7 bg-red-600 rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(239,68,68,0.7)]">
              <div className="w-0 h-0 border-y-[5px] border-y-transparent border-l-[9px] border-l-white ml-0.5"></div>
            </div>
            <span className="text-xl font-bold tracking-tight text-white">
              YouTube
            </span>
          </div>
        );
      case 'tcl':
        return (
          <div className="flex flex-col items-center">
            <span className="text-2xl font-black tracking-wider text-red-600 drop-shadow-[0_0_12px_rgba(220,38,38,0.5)]">
              TCL
            </span>
            <span className="text-[10px] font-bold tracking-[0.25em] text-white uppercase -mt-1">
              CHANNEL
            </span>
          </div>
        );
      case 'more':
        return (
          <div className="flex flex-col items-center gap-1.5">
            <LayoutGrid className="w-8 h-8 text-cyan-400 drop-shadow-[0_0_8px_rgba(6,182,212,0.6)]" />
          </div>
        );
      case 'add':
        return (
          <div className="flex flex-col items-center gap-1.5">
            <Plus className="w-8 h-8 text-slate-300 drop-shadow" />
          </div>
        );
      case 'netflix':
        return (
          <span className="text-2xl font-black tracking-widest text-red-600 drop-shadow-[0_0_10px_rgba(220,38,38,0.8)]">
            NETFLIX
          </span>
        );
      case 'prime':
        return (
          <span className="text-xl font-black tracking-wide text-cyan-400">
            prime<span className="text-white text-base font-medium">video</span>
          </span>
        );
      case 'disney':
        return (
          <span className="text-xl font-black tracking-wider text-blue-400 drop-shadow-[0_0_8px_rgba(96,165,250,0.8)]">
            Disney+
          </span>
        );
      case 'max':
        return (
          <span className="text-2xl font-black tracking-widest text-blue-500">
            MAX
          </span>
        );
      case 'spotify':
        return (
          <span className="text-lg font-bold text-green-400">
            Spotify
          </span>
        );
      default:
        return (
          <div className="w-8 h-8 rounded-lg bg-slate-700 flex items-center justify-center text-white font-bold">
            {app.name.charAt(0)}
          </div>
        );
    }
  };

  return (
    <div className="relative w-full select-none" aria-label="Aplicativos favoritos">
      <div className="flex items-center gap-4 overflow-x-auto no-scrollbar py-2">
        {apps.map((app, idx) => {
          const isFocused = isFocusedZone && focusedIndex === idx;
          const isAddBtn = app.id === 'add_fav';
          const isMoreAppsBtn = app.id === 'more_apps';
          const showMenu = contextMenuAppId === app.id;

          return (
            <div key={app.id} className="relative shrink-0">
              <button
                onClick={() => {
                  soundEngine.playSelectSound();
                  onFocusChange(idx);
                  if (isAddBtn) {
                    onOpenAddModal();
                  } else if (isMoreAppsBtn) {
                    onOpenAllApps();
                  } else {
                    onLaunchApp(app);
                  }
                }}
                onContextMenu={(e) => {
                  e.preventDefault();
                  if (!isAddBtn && !isMoreAppsBtn) {
                    soundEngine.playFocusTick();
                    setContextMenuAppId(showMenu ? null : app.id);
                  }
                }}
                onMouseEnter={() => {
                  soundEngine.playFocusTick();
                  onFocusChange(idx);
                }}
                className={`relative w-48 h-26 rounded-2xl flex flex-col items-center justify-center px-4 transition-all duration-200 cursor-pointer text-center ${
                  isFocused
                    ? 'bg-slate-900/90 ring-[3px] ring-cyan-400 shadow-[0_0_30px_4px_rgba(6,182,212,0.65),inset_0_0_15px_rgba(6,182,212,0.2)] scale-105 z-20'
                    : 'bg-slate-900/60 hover:bg-slate-900/80 border border-white/10 hover:border-white/25 shadow-lg'
                } backdrop-blur-md`}
                aria-label={`Aplicativo ${app.name}, ${app.category}`}
              >
                {/* Active Focus Halo Glow Effect */}
                {isFocused && (
                  <div className="absolute -inset-1 rounded-2xl bg-cyan-500/20 blur-md pointer-events-none"></div>
                )}

                {/* Badge if present */}
                {app.badge && (
                  <div className="absolute top-2 right-2.5 px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-red-600/90 text-white shadow">
                    {app.badge}
                  </div>
                )}

                {/* Main Logo Content */}
                <div className="h-10 flex items-center justify-center">
                  {renderAppIcon(app)}
                </div>

                {/* Subtitle / Category text */}
                <span className="text-xs font-medium text-slate-300 mt-2 truncate max-w-full">
                  {isAddBtn ? '+ Favorito' : isMoreAppsBtn ? 'Mais Apps' : app.category || app.name}
                </span>
              </button>

              {/* Context Menu for managing favorites (mobile / right click / long press) */}
              {showMenu && (
                <div className="absolute -top-16 left-0 right-0 z-30 bg-slate-900 border border-cyan-500/50 rounded-xl p-1.5 shadow-2xl flex items-center justify-center gap-1 backdrop-blur-lg">
                  {idx > 0 && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        soundEngine.playFocusTick();
                        onMoveApp(idx, idx - 1);
                        setContextMenuAppId(null);
                      }}
                      className="p-1 rounded bg-slate-800 text-slate-200 hover:bg-cyan-600 hover:text-white"
                      title="Mover para a esquerda"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                    </button>
                  )}
                  {idx < apps.length - 2 && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        soundEngine.playFocusTick();
                        onMoveApp(idx, idx + 1);
                        setContextMenuAppId(null);
                      }}
                      className="p-1 rounded bg-slate-800 text-slate-200 hover:bg-cyan-600 hover:text-white"
                      title="Mover para a direita"
                    >
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      soundEngine.playBackSound();
                      onRemoveApp(app.id);
                      setContextMenuAppId(null);
                    }}
                    className="flex items-center gap-1 px-2 py-1 rounded bg-red-600/80 hover:bg-red-600 text-white text-[11px] font-semibold"
                    title="Excluir da tela inicial"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Excluir</span>
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
