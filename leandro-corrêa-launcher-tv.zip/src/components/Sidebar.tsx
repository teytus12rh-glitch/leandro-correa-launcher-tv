import React from 'react';
import { Home, Clapperboard, Tv, LayoutGrid, Settings, Bot } from 'lucide-react';
import { soundEngine } from '../utils/audio';

export type SidebarTabId = 'inicio' | 'filmes' | 'series' | 'aplicativos' | 'configuracoes';

interface SidebarProps {
  activeTab: SidebarTabId;
  onSelectTab: (tab: SidebarTabId) => void;
  isFocusedZone: boolean;
  focusedIndex: number;
  onFocusChange: (index: number) => void;
}

export const SIDEBAR_ITEMS: { id: SidebarTabId; label: string; icon: React.FC<{ className?: string }> }[] = [
  { id: 'inicio', label: 'Início', icon: Home },
  { id: 'filmes', label: 'Filmes', icon: Clapperboard },
  { id: 'series', label: 'Séries', icon: Tv },
  { id: 'aplicativos', label: 'Aplicativos', icon: LayoutGrid },
  { id: 'configuracoes', label: 'Configurações', icon: Settings },
];

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  isFocusedZone,
  focusedIndex,
  onFocusChange,
}) => {
  return (
    <aside className="relative flex flex-col justify-between w-48 shrink-0 h-full py-2 pr-3 select-none">
      {/* Navigation Menu Items */}
      <nav className="flex flex-col gap-2.5" aria-label="Menu principal do launcher">
        {SIDEBAR_ITEMS.map((item, idx) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          const isFocused = isFocusedZone && focusedIndex === idx;

          return (
            <button
              key={item.id}
              onClick={() => {
                soundEngine.playSelectSound();
                onSelectTab(item.id);
                onFocusChange(idx);
              }}
              onMouseEnter={() => {
                soundEngine.playFocusTick();
                onFocusChange(idx);
              }}
              className={`group flex items-center gap-3.5 px-4 py-3 rounded-2xl font-medium transition-all duration-200 text-left cursor-pointer ${
                isFocused
                  ? 'bg-slate-800/90 text-cyan-300 ring-2 ring-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.4)] scale-105'
                  : isActive
                  ? 'bg-slate-800/80 text-white shadow-md border border-slate-700/60'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
              }`}
              aria-label={`Acessar aba ${item.label}`}
            >
              <Icon
                className={`w-5 h-5 transition-transform duration-200 ${
                  isFocused || isActive ? 'text-white scale-110 drop-shadow' : 'text-slate-400 group-hover:text-slate-200'
                }`}
              />
              <span className="text-sm font-semibold tracking-wide">
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Bottom section with cursive greeting and remote navigation helper */}
      <div className="flex flex-col gap-3 pt-6">
        {/* "Boa diversão!" in elegant cursive script font */}
        <div className="pl-3">
          <span className="font-script text-2xl text-slate-400/90 italic tracking-wider">
            Boa diversão!
          </span>
        </div>

        {/* Remote OK helper pill */}
        <div className="flex items-center gap-2 px-3 py-2 rounded-full bg-slate-900/80 border border-slate-700/60 shadow-inner">
          <div className="relative w-5 h-5 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-[0_0_8px_rgba(6,182,212,0.6)]">
            <Bot className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="text-[11px] text-slate-300 font-medium tracking-tight">
            Pressione OK para navegar
          </span>
        </div>
      </div>
    </aside>
  );
};
