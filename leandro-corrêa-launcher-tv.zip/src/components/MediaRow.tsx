import React from 'react';
import { Play } from 'lucide-react';
import { MediaItem } from '../types/launcher';
import { soundEngine } from '../utils/audio';

interface MediaRowProps {
  mediaItems: MediaItem[];
  isFocusedZone: boolean;
  focusedIndex: number;
  onFocusChange: (index: number) => void;
  onSelectMedia: (item: MediaItem) => void;
}

export const MediaRow: React.FC<MediaRowProps> = ({
  mediaItems,
  isFocusedZone,
  focusedIndex,
  onFocusChange,
  onSelectMedia,
}) => {
  return (
    <div className="relative w-full select-none" aria-label="Recomendações de Filmes e Séries">
      <div className="flex items-center gap-3.5 overflow-x-auto no-scrollbar py-2">
        {mediaItems.map((item, idx) => {
          const isFocused = isFocusedZone && focusedIndex === idx;

          return (
            <button
              key={item.id}
              onClick={() => {
                soundEngine.playSelectSound();
                onFocusChange(idx);
                onSelectMedia(item);
              }}
              onMouseEnter={() => {
                soundEngine.playFocusTick();
                onFocusChange(idx);
              }}
              className={`group relative shrink-0 w-36 h-48 sm:w-40 sm:h-52 rounded-2xl overflow-hidden transition-all duration-200 cursor-pointer text-left ${
                isFocused
                  ? 'ring-[3px] ring-cyan-400 shadow-[0_0_25px_4px_rgba(6,182,212,0.6)] scale-105 z-20'
                  : 'border border-white/10 hover:border-white/30 shadow-lg'
              }`}
              aria-label={`${item.title}, ${item.type}`}
            >
              {/* Background Poster Image */}
              <img
                src={item.posterUrl}
                alt={item.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                loading="lazy"
              />

              {/* Dark Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent"></div>

              {/* Title & Tag at bottom */}
              <div className="absolute bottom-0 left-0 right-0 p-3 flex flex-col justify-end">
                <span className="text-xs sm:text-sm font-extrabold text-white uppercase tracking-tight leading-tight line-clamp-2 drop-shadow-md">
                  {item.title}
                </span>

                <div className="flex items-center gap-1.5 mt-1">
                  <div className="w-4 h-4 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                    <Play className="w-2.5 h-2.5 text-white fill-white ml-0.5" />
                  </div>
                  <span className="text-[10px] font-semibold text-slate-300">
                    {item.type}
                  </span>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Bottom Right Pagination Dots (as in original screenshot) */}
      <div className="flex items-center justify-end gap-1.5 pt-3 pr-2">
        <div className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(6,182,212,0.8)]"></div>
        <div className="w-1.5 h-1.5 rounded-full bg-slate-600"></div>
        <div className="w-1.5 h-1.5 rounded-full bg-slate-600"></div>
        <div className="w-1.5 h-1.5 rounded-full bg-slate-600"></div>
      </div>
    </div>
  );
};
