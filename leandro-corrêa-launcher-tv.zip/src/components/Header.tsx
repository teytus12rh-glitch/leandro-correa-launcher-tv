import React from 'react';
import { Wifi, Settings, Tv, Smartphone, Volume2, VolumeX, ShieldCheck, Gamepad2 } from 'lucide-react';
import { formatLauncherDate, formatLauncherDateSubline, formatLauncherTime } from '../utils/launcherLogic';
import { soundEngine } from '../utils/audio';

interface HeaderProps {
  currentTime: Date;
  isSimulatedTime: boolean;
  onToggleTimeMode: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  isMobilePreview: boolean;
  onToggleMobilePreview: () => void;
  showVirtualRemote: boolean;
  onToggleVirtualRemote: () => void;
  onOpenSettings: () => void;
  onOpenCreator: () => void;
  onOpenApkDownload: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTime,
  isSimulatedTime,
  soundEnabled,
  onToggleSound,
  isMobilePreview,
  onToggleMobilePreview,
  showVirtualRemote,
  onToggleVirtualRemote,
  onOpenSettings,
  onOpenCreator,
  onOpenApkDownload,
}) => {
  const timeStr = formatLauncherTime(currentTime);
  const { dayOfWeek, fullDate } = formatLauncherDate(currentTime, isSimulatedTime);
  const subline = formatLauncherDateSubline(currentTime);

  return (
    <header className="relative z-10 w-full px-6 pt-5 pb-3 flex items-center justify-between select-none">
      {/* Brand & Creator Logo (Top Left) */}
      <button
        onClick={onOpenCreator}
        className="group flex items-center gap-3.5 focus:outline-none text-left transition-transform hover:scale-105 active:scale-95 cursor-pointer"
        title="Ver informações do criador: Leandro Corrêa"
        aria-label="Abrir tela de informações do criador Leandro Corrêa"
      >
        <div className="relative w-12 h-11 flex items-center justify-center">
          {/* Ambient neon halo */}
          <div className="absolute inset-0 bg-cyan-500/30 rounded-xl blur-md group-hover:bg-cyan-400/50 transition-all"></div>
          {/* TV icon box with gradient */}
          <div className="relative w-12 h-11 rounded-xl bg-gradient-to-br from-cyan-400 via-blue-600 to-indigo-800 p-[1.5px] shadow-lg shadow-cyan-500/20">
            <div className="w-full h-full bg-[#0a1120] rounded-[10px] flex items-center justify-center">
              <div className="w-0 h-0 border-y-[6px] border-y-transparent border-l-[10px] border-l-cyan-400 ml-0.5 filter drop-shadow-[0_0_6px_rgba(6,182,212,0.8)]"></div>
            </div>
          </div>
          {/* TV antenna legs */}
          <div className="absolute -bottom-1 left-2.5 w-1.5 h-1.5 bg-cyan-400/80 rounded-full"></div>
          <div className="absolute -bottom-1 right-2.5 w-1.5 h-1.5 bg-cyan-400/80 rounded-full"></div>
        </div>

        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className="text-xl font-bold tracking-tight text-white drop-shadow-md">
              Leandro Corrêa
            </span>
            <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 bg-cyan-500/20 text-cyan-300 rounded border border-cyan-500/30">
              Criador
            </span>
          </div>
          <span className="text-[11px] font-semibold text-cyan-400 tracking-[0.28em] uppercase -mt-0.5 drop-shadow-[0_0_8px_rgba(6,182,212,0.5)]">
            L A U N C H E R
          </span>
        </div>
      </button>

      {/* Center Controls (Mobile preview, Virtual remote, Audio) */}
      <div className="hidden md:flex items-center gap-2 bg-slate-900/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-slate-700/50 shadow-inner">
        <button
          onClick={onToggleSound}
          className={`px-2.5 py-1 rounded-full text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
            soundEnabled ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'text-slate-400 hover:text-white'
          }`}
          title="Ativar/Desativar Sons Modernos de Navegação"
          aria-label="Alternar som do sistema"
        >
          {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-cyan-400" /> : <VolumeX className="w-3.5 h-3.5 text-slate-500" />}
          <span>{soundEnabled ? 'Som TV Ligado' : 'Mudo'}</span>
        </button>

        <button
          onClick={onToggleVirtualRemote}
          className={`px-2.5 py-1 rounded-full text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
            showVirtualRemote ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40' : 'text-slate-400 hover:text-white'
          }`}
          title="Abrir Controle Remoto Virtual para Testes"
          aria-label="Alternar controle remoto virtual"
        >
          <Gamepad2 className="w-3.5 h-3.5" />
          <span>Controle TV</span>
        </button>

        <button
          onClick={onToggleMobilePreview}
          className={`px-2.5 py-1 rounded-full text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
            isMobilePreview ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'text-slate-400 hover:text-white'
          }`}
          title="Simular visualização em smartphone"
          aria-label="Alternar modo celular"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Modo Celular</span>
        </button>

        <button
          onClick={() => {
            soundEngine.playSelectSound();
            onOpenApkDownload();
          }}
          className="px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-[0_0_12px_rgba(16,185,129,0.5)] hover:scale-105 active:scale-95 transition-all cursor-pointer"
          title="Baixar APK e Instalar na TV"
          aria-label="Baixar APK"
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Baixar APK</span>
        </button>
      </div>

      {/* Clock, Date & Status Indicators (Top Right) */}
      <div className="flex items-center gap-5">
        <div className="flex items-center gap-4 text-right">
          {/* Big Digital Clock */}
          <div className="text-3xl font-extrabold tracking-tight text-white drop-shadow-md">
            {timeStr}
          </div>

          {/* Vertical Divider Line */}
          <div className="w-[1.5px] h-9 bg-slate-600/70"></div>

          {/* Date Information */}
          <div className="flex flex-col text-left">
            <span className="text-sm font-semibold text-slate-100 leading-tight">
              {dayOfWeek}
            </span>
            <span className="text-xs text-slate-300 leading-tight">
              {fullDate}
            </span>
            <span className="text-[10px] text-slate-400 font-mono tracking-tight mt-0.5">
              {subline}
            </span>
          </div>
        </div>

        {/* Status Icons */}
        <div className="flex items-center gap-3 pl-2">
          {/* Wi-Fi Icon */}
          <div className="text-slate-300 hover:text-cyan-400 transition-colors" title="Wi-Fi 5GHz Conectado (TCL OLED 55)">
            <Wifi className="w-5 h-5 text-slate-200" />
          </div>

          {/* Settings Icon */}
          <button
            onClick={onOpenSettings}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all focus:outline-none focus:ring-2 focus:ring-cyan-400 cursor-pointer"
            title="Configurações do Launcher"
            aria-label="Abrir configurações do sistema"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
};
