import React from 'react';
import { X, Tv, ShieldCheck, Cpu, Smartphone, Sparkles, Volume2, HardDrive, CheckCircle2 } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface CreatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenApkGuide: () => void;
}

export const CreatorModal: React.FC<CreatorModalProps> = ({
  isOpen,
  onClose,
  onOpenApkGuide,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in select-none">
      <div className="relative w-full max-w-3xl bg-slate-900/95 border-2 border-cyan-400/80 rounded-3xl p-6 sm:p-8 shadow-[0_0_60px_rgba(6,182,212,0.4)] overflow-y-auto max-h-[90vh]">
        {/* Close Button */}
        <button
          onClick={() => {
            soundEngine.playBackSound();
            onClose();
          }}
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
          aria-label="Fechar janela"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Top Header */}
        <div className="flex flex-col sm:flex-row items-center gap-5 pb-6 border-b border-slate-700/80">
          <div className="relative w-20 h-20 rounded-2xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-700 p-1 shadow-[0_0_25px_rgba(6,182,212,0.6)] shrink-0">
            <div className="w-full h-full bg-[#0a1120] rounded-[14px] flex items-center justify-center">
              <Tv className="w-10 h-10 text-cyan-400" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-emerald-500 border-2 border-slate-900 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4 text-white" />
            </div>
          </div>

          <div className="text-center sm:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-semibold mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Criação Exclusiva & Oficial</span>
            </div>
            <h2 className="text-3xl font-extrabold text-white tracking-tight">
              Leandro Corrêa
            </h2>
            <p className="text-sm font-medium text-cyan-400 tracking-wider uppercase mt-0.5">
              Criador & Desenvolvedor do Launcher TV
            </p>
            <p className="text-xs text-slate-400 mt-1 max-w-md">
              Desenvolvido com tecnologia de ponta para entregar a melhor experiência visual, fluidez extrema e sons modernos em Smart TVs.
            </p>
          </div>
        </div>

        {/* Target Devices Compatibility Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 my-6">
          <div className="p-4 rounded-2xl bg-slate-800/60 border border-cyan-500/30 flex flex-col items-center text-center">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 flex items-center justify-center text-cyan-400 mb-2">
              <Tv className="w-5 h-5" />
            </div>
            <span className="text-sm font-bold text-white">TCL OLED 55"</span>
            <span className="text-xs text-slate-400 mt-1">Google TV Certified</span>
            <span className="text-[11px] text-cyan-300 font-semibold mt-2 px-2 py-0.5 rounded bg-cyan-500/10">
              OLED Anti-Burn-In
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-800/60 border border-blue-500/30 flex flex-col items-center text-center">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center text-blue-400 mb-2">
              <HardDrive className="w-5 h-5" />
            </div>
            <span className="text-sm font-bold text-white">Xiaomi Mi TV Stick</span>
            <span className="text-xs text-slate-400 mt-1">1GB & 2GB RAM</span>
            <span className="text-[11px] text-emerald-300 font-semibold mt-2 px-2 py-0.5 rounded bg-emerald-500/10">
              Ultra Leve (&lt; 35MB)
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-800/60 border border-purple-500/30 flex flex-col items-center text-center">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center text-purple-400 mb-2">
              <Smartphone className="w-5 h-5" />
            </div>
            <span className="text-sm font-bold text-white">Smartphones Android</span>
            <span className="text-xs text-slate-400 mt-1">Testes em Mobile</span>
            <span className="text-[11px] text-purple-300 font-semibold mt-2 px-2 py-0.5 rounded bg-purple-500/10">
              Controle Virtual Touch
            </span>
          </div>
        </div>

        {/* Feature Highlights */}
        <div className="space-y-3 mb-6 bg-slate-950/50 p-4 rounded-2xl border border-slate-800">
          <h4 className="text-xs uppercase font-bold tracking-wider text-slate-400 mb-2">
            Arquitetura e Recursos Integrados:
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-300">
            <div className="flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>Sons Sintetizados em tempo real (0ms lag)</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Gestão de Favoritos (adicionar, excluir, reordenar)</span>
            </div>
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-blue-400 shrink-0" />
              <span>Navegação D-Pad precisa com controle de Smart TV</span>
            </div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
              <span>Entradas HDMI 1, HDMI 2 (eARC) e HDMI 3</span>
            </div>
          </div>
        </div>

        {/* Actions Bottom */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-800">
          <div className="text-xs text-slate-400 text-center sm:text-left">
            Versão 2.5 Pro OLED Edition • Criador: <strong className="text-white">Leandro Corrêa</strong>
          </div>
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={() => {
                soundEngine.playSelectSound();
                onOpenApkGuide();
              }}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-sm shadow-[0_0_15px_rgba(6,182,212,0.4)] transition-all cursor-pointer"
            >
              Como Instalar na TCL / Mi Stick (APK)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
