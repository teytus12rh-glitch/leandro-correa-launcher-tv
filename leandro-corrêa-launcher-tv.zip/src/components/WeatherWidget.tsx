import React from 'react';
import { MapPin, Droplets, Wind, Sun, Compass, CloudSun, CloudRain } from 'lucide-react';
import { WeatherData } from '../types/launcher';
import { soundEngine } from '../utils/audio';

interface WeatherWidgetProps {
  weather: WeatherData;
  isFocused: boolean;
  onSelect: () => void;
  onOpenSettings: () => void;
}

export const WeatherWidget: React.FC<WeatherWidgetProps> = ({
  weather,
  isFocused,
  onSelect,
  onOpenSettings,
}) => {
  return (
    <div
      onClick={() => {
        soundEngine.playSelectSound();
        onSelect();
      }}
      className={`relative w-full rounded-3xl p-5 transition-all duration-300 select-none cursor-pointer overflow-hidden border ${
        isFocused
          ? 'bg-slate-900/80 border-cyan-400 ring-2 ring-cyan-400/80 shadow-[0_0_30px_rgba(6,182,212,0.35)] scale-[1.01]'
          : 'bg-slate-900/50 hover:bg-slate-900/65 border-white/10 hover:border-white/20'
      } backdrop-blur-xl`}
      style={{
        boxShadow: isFocused
          ? '0 10px 40px -10px rgba(6,182,212,0.3), inset 0 0 20px rgba(6,182,212,0.1)'
          : '0 8px 32px 0 rgba(0, 0, 0, 0.37)',
      }}
    >
      {/* Subtle ambient gradient back-glow */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="relative z-10 flex flex-wrap items-center justify-between gap-6">
        {/* Left: 3D Weather Icon, Temperature & Location */}
        <div className="flex items-center gap-4">
          {/* Weather Icon (3D Moon & Cloud) */}
          <div className="relative w-16 h-16 flex items-center justify-center shrink-0">
            {/* Glowing Moon */}
            <div className="absolute top-1 right-2 w-9 h-9 rounded-full bg-slate-200/90 shadow-[0_0_15px_rgba(255,255,255,0.7)] flex items-center justify-center overflow-hidden">
              <div className="absolute -top-1 -right-1 w-7 h-7 rounded-full bg-[#111827]"></div>
            </div>
            {/* Soft Fluffy Cloud */}
            <div className="absolute bottom-1 left-1 w-13 h-8 bg-gradient-to-t from-slate-200 to-white rounded-full shadow-[0_4px_12px_rgba(0,0,0,0.3)] flex items-center justify-center">
              <div className="absolute -top-3 left-3 w-6 h-6 bg-white rounded-full"></div>
              <div className="absolute -top-1 right-2 w-5 h-5 bg-white rounded-full"></div>
            </div>
          </div>

          <div className="flex flex-col">
            <div className="flex items-baseline gap-1">
              <span className="text-4xl font-extrabold text-white tracking-tight">
                {weather.temperature}°C
              </span>
            </div>
            <span className="text-sm font-medium text-slate-200">
              {weather.condition}
            </span>
            <div className="flex items-center gap-1 text-slate-400 text-xs mt-0.5">
              <MapPin className="w-3.5 h-3.5 text-cyan-400" />
              <span>{weather.city} - {weather.state}</span>
            </div>
          </div>
        </div>

        {/* Middle: 5-Day Forecast Columns */}
        <div className="hidden lg:flex items-center gap-5 px-4 py-1.5 rounded-2xl bg-slate-850/40 border border-white/5">
          {weather.forecast.map((item, i) => (
            <div key={i} className="flex flex-col items-center gap-1 text-center min-w-[42px]">
              <span className="text-xs font-semibold text-slate-300">
                {item.day}
              </span>
              <div className="my-0.5">
                {item.condition === 'sun' ? (
                  <Sun className="w-5 h-5 text-amber-400 drop-shadow-[0_0_6px_rgba(251,191,36,0.5)]" />
                ) : item.condition === 'rain' ? (
                  <CloudRain className="w-5 h-5 text-blue-400 drop-shadow-[0_0_6px_rgba(96,165,250,0.5)]" />
                ) : (
                  <CloudSun className="w-5 h-5 text-amber-300 drop-shadow-[0_0_6px_rgba(252,211,77,0.5)]" />
                )}
              </div>
              <span className="text-[11px] font-medium text-slate-300">
                {item.max}° / {item.min}°
              </span>
            </div>
          ))}
        </div>

        {/* Right: Weather Stats & Measurements */}
        <div className="flex flex-col gap-1 text-xs text-slate-300 shrink-0">
          <div className="flex items-center gap-2">
            <Droplets className="w-3.5 h-3.5 text-cyan-400" />
            <span>Umidade <strong className="font-semibold text-white">{weather.humidity}%</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <Wind className="w-3.5 h-3.5 text-cyan-400" />
            <span>Vento <strong className="font-semibold text-white">{weather.windSpeed} km/h</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <Sun className="w-3.5 h-3.5 text-amber-400" />
            <span>Índice UV <strong className="font-semibold text-white">{weather.uvIndex} ({weather.uvDescription})</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <Compass className="w-3.5 h-3.5 text-cyan-400" />
            <span>Pressão <strong className="font-semibold text-white">{weather.pressure} hPa</strong></span>
          </div>
        </div>

        {/* Far Right: Cursive Quote */}
        <div className="hidden xl:flex items-center pl-2 max-w-[170px] text-right">
          <p className="font-script text-2xl text-slate-300/90 leading-tight italic drop-shadow">
            "{weather.quote}"
          </p>
        </div>
      </div>
    </div>
  );
};
