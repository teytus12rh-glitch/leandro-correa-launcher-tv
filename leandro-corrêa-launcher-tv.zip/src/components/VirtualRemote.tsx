import React from 'react';
import { ChevronUp, ChevronDown, ChevronLeft, ChevronRight, CornerDownLeft, Home, Menu, Volume2, Volume1, Power, X } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface VirtualRemoteProps {
  isOpen: boolean;
  onClose: () => void;
  onDpadUp: () => void;
  onDpadDown: () => void;
  onDpadLeft: () => void;
  onDpadRight: () => void;
  onSelectOk: () => void;
  onBack: () => void;
  onHome: () => void;
  onMenu: () => void;
}

export const VirtualRemote: React.FC<VirtualRemoteProps> = ({
  isOpen,
  onClose,
  onDpadUp,
  onDpadDown,
  onDpadLeft,
  onDpadRight,
  onSelectOk,
  onBack,
  onHome,
  onMenu,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-center select-none animate-fade-in drop-shadow-2xl">
      {/* Remote Chassis */}
      <div className="w-56 bg-slate-950/95 border-2 border-cyan-500/50 rounded-[38px] p-4.5 shadow-[0_15px_45px_rgba(0,0,0,0.8),0_0_25px_rgba(6,182,212,0.3)] backdrop-blur-xl">
        {/* Remote Header / Branding */}
        <div className="flex items-center justify-between pb-3 px-1 border-b border-slate-800">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(6,182,212,0.9)] animate-pulse"></div>
            <span className="text-[11px] font-extrabold text-slate-300 tracking-wider">
              TCL / MI REMOTE
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Fechar controle"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Top Control Bar: Power, Home, Menu */}
        <div className="flex items-center justify-between px-2 pt-3 pb-2">
          <button
            onClick={() => {
              soundEngine.playBackSound();
              onHome();
            }}
            className="w-10 h-10 rounded-full bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-400 hover:border-cyan-500/50 flex items-center justify-center transition-all active:scale-90"
            title="Botão Home"
          >
            <Home className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              soundEngine.playSelectSound();
              onMenu();
            }}
            className="w-10 h-10 rounded-full bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-400 hover:border-cyan-500/50 flex items-center justify-center transition-all active:scale-90"
            title="Botão Menu / Configurações"
          >
            <Menu className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              soundEngine.playBackSound();
              onBack();
            }}
            className="w-10 h-10 rounded-full bg-slate-900 border border-slate-800 text-slate-300 hover:text-red-400 hover:border-red-500/50 flex items-center justify-center transition-all active:scale-90"
            title="Botão Voltar"
          >
            <CornerDownLeft className="w-4 h-4" />
          </button>
        </div>

        {/* D-Pad Circle Container */}
        <div className="relative w-44 h-44 my-4 mx-auto bg-slate-900/90 rounded-full border-2 border-slate-700/80 shadow-inner flex items-center justify-center">
          {/* UP */}
          <button
            onClick={() => {
              soundEngine.playFocusTick();
              onDpadUp();
            }}
            className="absolute top-1 left-1/2 -translate-x-1/2 w-14 h-12 flex items-center justify-center text-slate-300 hover:text-cyan-400 active:scale-95 transition-transform"
            title="Cima"
            aria-label="Controle D-pad Cima"
          >
            <ChevronUp className="w-6 h-6" />
          </button>

          {/* DOWN */}
          <button
            onClick={() => {
              soundEngine.playFocusTick();
              onDpadDown();
            }}
            className="absolute bottom-1 left-1/2 -translate-x-1/2 w-14 h-12 flex items-center justify-center text-slate-300 hover:text-cyan-400 active:scale-95 transition-transform"
            title="Baixo"
            aria-label="Controle D-pad Baixo"
          >
            <ChevronDown className="w-6 h-6" />
          </button>

          {/* LEFT */}
          <button
            onClick={() => {
              soundEngine.playFocusTick();
              onDpadLeft();
            }}
            className="absolute left-1 top-1/2 -translate-y-1/2 w-12 h-14 flex items-center justify-center text-slate-300 hover:text-cyan-400 active:scale-95 transition-transform"
            title="Esquerda"
            aria-label="Controle D-pad Esquerda"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* RIGHT */}
          <button
            onClick={() => {
              soundEngine.playFocusTick();
              onDpadRight();
            }}
            className="absolute right-1 top-1/2 -translate-y-1/2 w-12 h-14 flex items-center justify-center text-slate-300 hover:text-cyan-400 active:scale-95 transition-transform"
            title="Direita"
            aria-label="Controle D-pad Direita"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* CENTER OK BUTTON */}
          <button
            onClick={() => {
              soundEngine.playSelectSound();
              onSelectOk();
            }}
            className="w-18 h-18 rounded-full bg-gradient-to-tr from-cyan-600 via-blue-600 to-indigo-700 text-white font-extrabold text-base flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.6)] active:scale-90 transition-all cursor-pointer"
            title="Botão OK"
            aria-label="Controle Botão OK"
          >
            OK
          </button>
        </div>

        {/* Volume & Helper Bar */}
        <div className="flex items-center justify-between px-3 pt-2 text-[10px] text-slate-400 font-medium">
          <span>D-PAD TV</span>
          <span className="text-cyan-400 font-bold">LEANDRO CORRÊA</span>
        </div>
      </div>
    </div>
  );
};
