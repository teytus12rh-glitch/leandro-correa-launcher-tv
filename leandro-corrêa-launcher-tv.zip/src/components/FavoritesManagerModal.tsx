import React, { useState } from 'react';
import { X, Plus, Trash2, ArrowLeft, ArrowRight, RotateCcw, Check, Sparkles } from 'lucide-react';
import { AppItem } from '../types/launcher';
import { CATALOG_APPS, INITIAL_FAVORITE_APPS } from '../data/defaultData';
import { soundEngine } from '../utils/audio';

interface FavoritesManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  favoriteApps: AppItem[];
  onAddApp: (app: AppItem) => void;
  onRemoveApp: (appId: string) => void;
  onMoveApp: (fromIndex: number, toIndex: number) => void;
  onResetDefaults: () => void;
}

export const FavoritesManagerModal: React.FC<FavoritesManagerModalProps> = ({
  isOpen,
  onClose,
  favoriteApps,
  onAddApp,
  onRemoveApp,
  onMoveApp,
  onResetDefaults,
}) => {
  const [activeTab, setActiveTab] = useState<'current' | 'catalog' | 'custom'>('current');
  const [customName, setCustomName] = useState('');
  const [customCategory, setCustomCategory] = useState('');

  if (!isOpen) return null;

  const handleAddCustomApp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim()) return;

    const newApp: AppItem = {
      id: `custom_${Date.now()}`,
      name: customName.trim(),
      category: customCategory.trim() || 'Aplicativo',
      iconType: 'custom',
      iconColor: '#06b6d4',
      isCustom: true,
    };

    soundEngine.playSelectSound();
    onAddApp(newApp);
    setCustomName('');
    setCustomCategory('');
    setActiveTab('current');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in select-none">
      <div className="relative w-full max-w-2xl bg-slate-900 border-2 border-cyan-500/60 rounded-3xl p-6 shadow-[0_0_50px_rgba(6,182,212,0.35)] max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 shrink-0">
          <div>
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-cyan-400" />
              <span>Gerenciar Aplicativos Favoritos</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Adicione, exclua ou reordene os apps que aparecem na tela inicial do seu Launcher
            </p>
          </div>
          <button
            onClick={() => {
              soundEngine.playBackSound();
              onClose();
            }}
            className="p-2 rounded-full bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex gap-2 pt-4 pb-3 shrink-0">
          <button
            onClick={() => {
              soundEngine.playFocusTick();
              setActiveTab('current');
            }}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'current'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow'
                : 'bg-slate-800/80 text-slate-400 hover:text-white'
            }`}
          >
            Apps Atuais na Tela ({favoriteApps.filter(a => a.id !== 'add_fav').length})
          </button>
          <button
            onClick={() => {
              soundEngine.playFocusTick();
              setActiveTab('catalog');
            }}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'catalog'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow'
                : 'bg-slate-800/80 text-slate-400 hover:text-white'
            }`}
          >
            Catálogo de Apps (+ Streaming)
          </button>
          <button
            onClick={() => {
              soundEngine.playFocusTick();
              setActiveTab('custom');
            }}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'custom'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow'
                : 'bg-slate-800/80 text-slate-400 hover:text-white'
            }`}
          >
            + Adicionar Manual
          </button>
        </div>

        {/* Tab Content */}
        <div className="overflow-y-auto flex-1 pr-1 py-2 space-y-3">
          {activeTab === 'current' && (
            <div className="space-y-2">
              {favoriteApps
                .filter(app => app.id !== 'add_fav')
                .map((app, index) => (
                  <div
                    key={app.id}
                    className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-800/70 border border-slate-700/60"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-mono text-cyan-400 w-5">
                        #{index + 1}
                      </span>
                      <div>
                        <div className="text-sm font-bold text-white">{app.name}</div>
                        <div className="text-xs text-slate-400">{app.category}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {index > 0 && (
                        <button
                          onClick={() => {
                            soundEngine.playFocusTick();
                            onMoveApp(index, index - 1);
                          }}
                          className="p-1.5 rounded-lg bg-slate-700 text-slate-300 hover:text-white hover:bg-slate-600 transition-colors"
                          title="Mover para cima/esquerda"
                        >
                          <ArrowLeft className="w-4 h-4" />
                        </button>
                      )}
                      {index < favoriteApps.length - 2 && (
                        <button
                          onClick={() => {
                            soundEngine.playFocusTick();
                            onMoveApp(index, index + 1);
                          }}
                          className="p-1.5 rounded-lg bg-slate-700 text-slate-300 hover:text-white hover:bg-slate-600 transition-colors"
                          title="Mover para baixo/direita"
                        >
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      )}
                      {app.id !== 'more_apps' && (
                        <button
                          onClick={() => {
                            soundEngine.playBackSound();
                            onRemoveApp(app.id);
                          }}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-red-600/80 hover:bg-red-600 text-white text-xs font-semibold ml-2 transition-colors cursor-pointer"
                          title="Excluir dos favoritos"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Excluir</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
            </div>
          )}

          {activeTab === 'catalog' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {CATALOG_APPS.map(app => {
                const isAlreadyInFav = favoriteApps.some(f => f.id === app.id);

                return (
                  <div
                    key={app.id}
                    className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700/60"
                  >
                    <div>
                      <div className="text-sm font-bold text-white">{app.name}</div>
                      <div className="text-xs text-slate-400">{app.category}</div>
                    </div>

                    {isAlreadyInFav ? (
                      <span className="flex items-center gap-1 text-emerald-400 text-xs font-semibold px-2 py-1 bg-emerald-500/10 rounded-lg">
                        <Check className="w-3.5 h-3.5" />
                        <span>Adicionado</span>
                      </span>
                    ) : (
                      <button
                        onClick={() => {
                          soundEngine.playSelectSound();
                          onAddApp(app);
                        }}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-colors cursor-pointer shadow-[0_0_10px_rgba(6,182,212,0.4)]"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Incluir</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'custom' && (
            <form onSubmit={handleAddCustomApp} className="space-y-4 p-2">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Nome do Aplicativo
                </label>
                <input
                  type="text"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  placeholder="Ex: IPTV Smarters Pro, Crunchyroll, etc."
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-400"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Categoria / Subtítulo
                </label>
                <input
                  type="text"
                  value={customCategory}
                  onChange={(e) => setCustomCategory(e.target.value)}
                  placeholder="Ex: Canais Ao Vivo, Anime, Música"
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-400"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm shadow-[0_0_15px_rgba(6,182,212,0.4)] transition-all cursor-pointer"
              >
                Salvar e Incluir na Tela Inicial
              </button>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="pt-4 mt-2 border-t border-slate-800 flex items-center justify-between shrink-0">
          <button
            onClick={() => {
              soundEngine.playBackSound();
              onResetDefaults();
            }}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restaurar Padrão da Imagem</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playSelectSound();
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition-colors cursor-pointer"
          >
            Concluir
          </button>
        </div>
      </div>
    </div>
  );
};
