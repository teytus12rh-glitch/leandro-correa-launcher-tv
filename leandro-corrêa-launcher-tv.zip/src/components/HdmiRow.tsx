import React from 'react';
import { Tv, Cable } from 'lucide-react';
import { HdmiSource } from '../types/launcher';
import { soundEngine } from '../utils/audio';

interface HdmiRowProps {
  sources: HdmiSource[];
  isFocusedZone: boolean;
  focusedIndex: number;
  onFocusChange: (index: number) => void;
  onSelectSource: (source: HdmiSource) => void;
}

export const HdmiRow: React.FC<HdmiRowProps> = ({
  sources,
  isFocusedZone,
  focusedIndex,
  onFocusChange,
  onSelectSource,
}) => {
  return (
    <div className="relative w-full select-none" aria-label="Entradas HDMI e fontes">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        {sources.map((source, idx) => {
          const isFocused = isFocusedZone && focusedIndex === idx;

          return (
            <button
              key={source.id}
              onClick={() => {
                soundEngine.playSelectSound();
                onFocusChange(idx);
                onSelectSource(source);
              }}
              onMouseEnter={() => {
                soundEngine.playFocusTick();
                onFocusChange(idx);
              }}
              className={`group flex items-center justify-center gap-3 px-5 py-3 rounded-2xl transition-all duration-200 cursor-pointer ${
                isFocused
                  ? 'bg-slate-900/90 ring-2 ring-cyan-400 shadow-[0_0_22px_rgba(6,182,212,0.5)] scale-[1.02]'
                  : 'bg-slate-900/50 hover:bg-slate-900/70 border border-white/10 hover:border-white/20 shadow-md'
              } backdrop-blur-md`}
              aria-label={`Entrada ${source.name}`}
            >
              {/* HDMI Port Icon */}
              <div className="w-7 h-4.5 rounded border border-slate-400/80 flex items-center justify-center bg-slate-800/80">
                <div className="w-4 h-2 border-t border-b border-cyan-400/70 flex items-center justify-center">
                  <div className="w-2 h-0.5 bg-cyan-400"></div>
                </div>
              </div>

              {/* Source Name */}
              <span className="text-sm font-semibold tracking-wide text-slate-100">
                {source.name}
              </span>

              {/* Status dot if connected */}
              {source.active && (
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)] ml-1"></div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
