import React from 'react';
import { X, Download, Tv, Smartphone, Terminal, HardDrive, Sparkles, CheckCircle2 } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface ApkGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkGuideModal: React.FC<ApkGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in select-none">
      <div className="relative w-full max-w-3xl bg-slate-900 border-2 border-cyan-400/70 rounded-3xl p-6 sm:p-8 shadow-[0_0_60px_rgba(6,182,212,0.4)] overflow-y-auto max-h-[90vh]">
        {/* Close Button */}
        <button
          onClick={() => {
            soundEngine.playBackSound();
            onClose();
          }}
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-4 pb-5 border-b border-slate-800">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-lg shrink-0">
            <Download className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-white">
              Guia de Instalação do APK
            </h3>
            <p className="text-xs text-cyan-400 font-medium">
              TCL OLED 55" Google TV • Xiaomi Mi TV Stick • Smartphones Android
            </p>
          </div>
        </div>

        {/* Steps Content */}
        <div className="py-5 space-y-6 text-sm text-slate-300">
          {/* Quick Action Download Box */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-cyan-950/60 border-2 border-emerald-500/60 shadow-[0_0_25px_rgba(16,185,129,0.3)] flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                <Download className="w-6 h-6" />
              </div>
              <div>
                <span className="text-base font-extrabold text-white block">
                  Baixar Pacote Pronto para TV (Android Build)
                </span>
                <span className="text-xs text-slate-300">
                  Inclui arquivos de produção, AndroidManifest TV e configurações prontas
                </span>
              </div>
            </div>

            <a
              href="/downloads/LeandroCorreaLauncher-TV.zip"
              download="LeandroCorreaLauncher-TV.zip"
              onClick={() => soundEngine.playSelectSound()}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-extrabold text-sm shadow-[0_0_20px_rgba(16,185,129,0.5)] transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>Baixar Pacote (.ZIP)</span>
            </a>
          </div>

          {/* Method 1: PWABuilder (Online em 2 min) */}
          <div className="p-4.5 rounded-2xl bg-gradient-to-r from-cyan-950/40 to-blue-950/40 border border-cyan-500/50">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-base font-bold text-white flex items-center gap-2 text-cyan-300">
                <Sparkles className="w-5 h-5 text-cyan-400" />
                <span>Opção 1: Gerar APK Assinado na Nuvem (1 Clique)</span>
              </h4>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 uppercase">
                Recomendado
              </span>
            </div>
            <p className="text-xs text-slate-300 mb-3">
              O PWABuilder compila seu launcher na nuvem em 30 segundos e entrega o arquivo <strong>.apk</strong> direto nos seus downloads:
            </p>
            <div className="flex flex-col sm:flex-row items-center gap-3">
              <a
                href="https://www.pwabuilder.com?site=https%3A%2F%2Fais-pre-hulkydwfypesyjts3g43fy-736264144770.us-west2.run.app"
                target="_blank"
                rel="noreferrer"
                onClick={() => soundEngine.playSelectSound()}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-[0_0_15px_rgba(6,182,212,0.4)] transition-all text-center cursor-pointer"
              >
                Abrir PWABuilder com seu App Pré-Carregado &rarr;
              </a>
              <span className="text-xs text-slate-400">
                Depois basta clicar em <em>"Package for Android"</em> e o APK é gerado!
              </span>
            </div>
          </div>

          {/* Method 2: TCL OLED 55 Google TV & Mi Stick */}
          <div className="p-4.5 rounded-2xl bg-slate-800/60 border border-slate-700/80">
            <h4 className="text-base font-bold text-white flex items-center gap-2 mb-2 text-emerald-300">
              <Tv className="w-5 h-5 text-emerald-400" />
              <span>Método 2: Instalação na TV via "Downloader" ou Pendrive USB</span>
            </h4>
            <ol className="list-decimal list-inside space-y-2 text-xs sm:text-sm text-slate-300 leading-relaxed">
              <li>
                Na sua TV TCL ou Mi Stick, instale o app <strong>"Downloader by AFTVnews"</strong> na Google Play Store.
              </li>
              <li>
                Vá em <strong>Configurações da TV &gt; Sistema &gt; Segurança</strong> e autorize <em>"Fontes Desconhecidas"</em> para o Downloader.
              </li>
              <li>
                No Downloader, digite o link do seu APK para baixar e instalar diretamente com 1 clique.
              </li>
              <li>
                <em>(Alternativa na TV TCL 55"):</em> Coloque o arquivo <code>.apk</code> em um pendrive USB, espete na TV e abra pelo app <strong>FX File Explorer</strong> para instalar.
              </li>
            </ol>
          </div>

          {/* Method 3: Definir como Launcher Padrão */}
          <div className="p-4.5 rounded-2xl bg-slate-800/60 border border-slate-700/80">
            <h4 className="text-base font-bold text-white flex items-center gap-2 mb-2 text-purple-300">
              <CheckCircle2 className="w-5 h-5 text-purple-400" />
              <span>Como Tornar o Launcher Padrão no Controle Remoto</span>
            </h4>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-3">
              Para fazer o <strong>Leandro Corrêa Launcher</strong> abrir sempre que ligar a TV ou apertar o botão Home:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-700">
                <span className="font-bold text-white block mb-1">Método A: App Button Mapper</span>
                <p className="text-slate-400 leading-normal">
                  Instale o app gratuito <em>Button Mapper</em> na Play Store da TV. Remapeie o botão Home do controle para abrir o <strong>Leandro Corrêa Launcher</strong> ao apertar uma vez.
                </p>
              </div>
              <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-700">
                <span className="font-bold text-white block mb-1">Método B: Desativar Launcher Original (ADB)</span>
                <p className="text-slate-400 font-mono text-[11px] leading-normal">
                  adb connect IP_DA_SUA_TV<br />
                  adb shell pm disable-user --user 0 com.google.android.apps.tv.launcherx
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={() => {
              soundEngine.playSelectSound();
              onClose();
            }}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-sm shadow-[0_0_15px_rgba(6,182,212,0.4)] cursor-pointer"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
