/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Header } from './components/Header';
import { Sidebar, SidebarTabId } from './components/Sidebar';
import { WeatherWidget } from './components/WeatherWidget';
import { AppRow } from './components/AppRow';
import { HdmiRow } from './components/HdmiRow';
import { MediaRow } from './components/MediaRow';
import { CreatorModal } from './components/CreatorModal';
import { SettingsModal } from './components/SettingsModal';
import { FavoritesManagerModal } from './components/FavoritesManagerModal';
import { ApkGuideModal } from './components/ApkGuideModal';
import { AppSimulatorModal } from './components/AppSimulatorModal';
import { VirtualRemote } from './components/VirtualRemote';
import { INITIAL_FAVORITE_APPS, INITIAL_HDMI_SOURCES, INITIAL_MEDIA_ITEMS, INITIAL_WEATHER } from './data/defaultData';
import { AppItem, FocusState, HdmiSource, MediaItem, WeatherData } from './types/launcher';
import { soundEngine } from './utils/audio';
import { addFavoriteApp, calculateNextFocus, moveFavoriteApp, removeFavoriteApp } from './utils/launcherLogic';
import { Smartphone, Tv } from 'lucide-react';

export default function App() {
  // Saved states from localStorage
  const [favoriteApps, setFavoriteApps] = useState<AppItem[]>(() => {
    const saved = localStorage.getItem('leandro_launcher_favorites');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_FAVORITE_APPS;
      }
    }
    return INITIAL_FAVORITE_APPS;
  });

  const [weather, setWeather] = useState<WeatherData>(INITIAL_WEATHER);
  const [activeTab, setActiveTab] = useState<SidebarTabId>('inicio');

  // Initial focus on YouTube (index 1 of 'apps') matching the reference image!
  const [focusState, setFocusState] = useState<FocusState>({
    zone: 'apps',
    index: 1,
  });

  // Toggles and settings
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => soundEngine.isSoundEnabled());
  const [ambientGlow, setAmbientGlow] = useState<boolean>(true);
  const [oledProtection, setOledProtection] = useState<boolean>(false);
  const [isSimulatedTime, setIsSimulatedTime] = useState<boolean>(true);
  const [isMobilePreview, setIsMobilePreview] = useState<boolean>(false);
  const [showVirtualRemote, setShowVirtualRemote] = useState<boolean>(false);

  // Time state (defaults to Saturday, 27 Sept 2026, 19:42 matching image)
  const [currentTime, setCurrentTime] = useState<Date>(() => {
    // 2026-09-27 19:42
    const d = new Date(2026, 8, 27, 19, 42);
    return d;
  });

  // Modals
  const [isCreatorOpen, setIsCreatorOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isFavoritesManagerOpen, setIsFavoritesManagerOpen] = useState(false);
  const [isApkGuideOpen, setIsApkGuideOpen] = useState(false);

  // Simulators
  const [activeSimulatorApp, setActiveSimulatorApp] = useState<AppItem | null>(null);
  const [activeSimulatorMedia, setActiveSimulatorMedia] = useState<MediaItem | null>(null);
  const [activeSimulatorHdmi, setActiveSimulatorHdmi] = useState<HdmiSource | null>(null);

  // Persist favorites
  useEffect(() => {
    localStorage.setItem('leandro_launcher_favorites', JSON.stringify(favoriteApps));
  }, [favoriteApps]);

  // Clock timer
  useEffect(() => {
    if (!isSimulatedTime) {
      const interval = setInterval(() => {
        setCurrentTime(new Date());
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [isSimulatedTime]);

  // Audio toggle helper
  const handleToggleSound = useCallback(() => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundEngine.setSoundEnabled(next);
  }, [soundEnabled]);

  // D-Pad navigation movement
  const handleNavigate = useCallback(
    (direction: 'up' | 'down' | 'left' | 'right') => {
      // Don't navigate main UI if any modal is open
      if (
        isCreatorOpen ||
        isSettingsOpen ||
        isFavoritesManagerOpen ||
        isApkGuideOpen ||
        activeSimulatorApp ||
        activeSimulatorMedia ||
        activeSimulatorHdmi
      ) {
        return;
      }

      setFocusState((prev) => {
        const next = calculateNextFocus(prev, direction, {
          sidebarCount: 5,
          appsCount: favoriteApps.length,
          hdmiCount: INITIAL_HDMI_SOURCES.length,
          mediaCount: INITIAL_MEDIA_ITEMS.length,
        });
        soundEngine.playFocusTick();
        return next;
      });
    },
    [
      favoriteApps.length,
      isCreatorOpen,
      isSettingsOpen,
      isFavoritesManagerOpen,
      isApkGuideOpen,
      activeSimulatorApp,
      activeSimulatorMedia,
      activeSimulatorHdmi,
    ]
  );

  // Select / OK button
  const handleSelectOk = useCallback(() => {
    if (activeSimulatorApp || activeSimulatorMedia || activeSimulatorHdmi) {
      return;
    }

    soundEngine.playSelectSound();

    if (focusState.zone === 'sidebar') {
      const tabs: SidebarTabId[] = ['inicio', 'filmes', 'series', 'aplicativos', 'configuracoes'];
      const tab = tabs[focusState.index];
      setActiveTab(tab);
      if (tab === 'configuracoes') {
        setIsSettingsOpen(true);
      } else if (tab === 'aplicativos') {
        setIsFavoritesManagerOpen(true);
      }
    } else if (focusState.zone === 'apps') {
      const app = favoriteApps[focusState.index];
      if (app) {
        if (app.id === 'add_fav') {
          setIsFavoritesManagerOpen(true);
        } else if (app.id === 'more_apps') {
          setIsFavoritesManagerOpen(true);
        } else {
          setActiveSimulatorApp(app);
        }
      }
    } else if (focusState.zone === 'hdmi') {
      const hdmi = INITIAL_HDMI_SOURCES[focusState.index];
      if (hdmi) {
        setActiveSimulatorHdmi(hdmi);
      }
    } else if (focusState.zone === 'media') {
      const media = INITIAL_MEDIA_ITEMS[focusState.index];
      if (media) {
        setActiveSimulatorMedia(media);
      }
    } else if (focusState.zone === 'weather') {
      setIsSettingsOpen(true);
    }
  }, [focusState, favoriteApps, activeSimulatorApp, activeSimulatorMedia, activeSimulatorHdmi]);

  // Back button
  const handleBack = useCallback(() => {
    soundEngine.playBackSound();
    if (activeSimulatorApp) setActiveSimulatorApp(null);
    else if (activeSimulatorMedia) setActiveSimulatorMedia(null);
    else if (activeSimulatorHdmi) setActiveSimulatorHdmi(null);
    else if (isCreatorOpen) setIsCreatorOpen(false);
    else if (isSettingsOpen) setIsSettingsOpen(false);
    else if (isFavoritesManagerOpen) setIsFavoritesManagerOpen(false);
    else if (isApkGuideOpen) setIsApkGuideOpen(false);
    else if (focusState.zone !== 'apps') {
      setFocusState({ zone: 'apps', index: 0 });
    }
  }, [
    activeSimulatorApp,
    activeSimulatorMedia,
    activeSimulatorHdmi,
    isCreatorOpen,
    isSettingsOpen,
    isFavoritesManagerOpen,
    isApkGuideOpen,
    focusState.zone,
  ]);

  // Keyboard remote control events (TV remote D-Pad, Arrow keys, Enter, Back)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Allow inputs in forms/modals without hijacking typing
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      switch (e.key) {
        case 'ArrowUp':
          e.preventDefault();
          handleNavigate('up');
          break;
        case 'ArrowDown':
          e.preventDefault();
          handleNavigate('down');
          break;
        case 'ArrowLeft':
          e.preventDefault();
          handleNavigate('left');
          break;
        case 'ArrowRight':
          e.preventDefault();
          handleNavigate('right');
          break;
        case 'Enter':
        case ' ':
          e.preventDefault();
          handleSelectOk();
          break;
        case 'Escape':
        case 'Backspace':
          e.preventDefault();
          handleBack();
          break;
        case 'h':
        case 'H':
          e.preventDefault();
          soundEngine.playBackSound();
          setActiveTab('inicio');
          setFocusState({ zone: 'apps', index: 1 });
          break;
        case 'm':
        case 'M':
          e.preventDefault();
          setIsSettingsOpen(true);
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleNavigate, handleSelectOk, handleBack]);

  // Favorites handlers
  const handleAddApp = useCallback((newApp: AppItem) => {
    setFavoriteApps((prev) => addFavoriteApp(prev, newApp));
  }, []);

  const handleRemoveApp = useCallback((appId: string) => {
    setFavoriteApps((prev) => removeFavoriteApp(prev, appId));
  }, []);

  const handleMoveApp = useCallback((fromIndex: number, toIndex: number) => {
    setFavoriteApps((prev) => moveFavoriteApp(prev, fromIndex, toIndex));
  }, []);

  const handleResetDefaults = useCallback(() => {
    setFavoriteApps(INITIAL_FAVORITE_APPS);
  }, []);

  // Filtered media by tab
  const displayedMedia = useMemo(() => {
    if (activeTab === 'filmes') {
      return INITIAL_MEDIA_ITEMS.filter((m) => m.type === 'Filme');
    }
    if (activeTab === 'series') {
      return INITIAL_MEDIA_ITEMS.filter((m) => m.type === 'Série');
    }
    return INITIAL_MEDIA_ITEMS;
  }, [activeTab]);

  return (
    <div
      className={`relative min-h-screen w-full flex flex-col justify-between overflow-x-hidden ${
        oledProtection ? 'bg-black' : 'bg-[#06090e]'
      } text-slate-100 font-sans selection:bg-cyan-500 selection:text-black`}
    >
      {/* Subtle Ambilight Backlight Glow */}
      {ambientGlow && !oledProtection && (
        <div className="tv-ambient-glow animate-pulse duration-1000"></div>
      )}

      {/* Main Wrapper (With Mobile Preview Container option) */}
      <div
        className={`relative z-10 w-full flex-1 flex flex-col transition-all duration-300 ${
          isMobilePreview
            ? 'max-w-[440px] mx-auto my-4 rounded-[42px] border-4 border-slate-700 bg-[#06090e] shadow-[0_0_50px_rgba(0,0,0,0.9)] overflow-hidden min-h-[880px]'
            : 'max-w-[1920px] mx-auto'
        }`}
      >
        {/* Mobile Preview Top Status Bar (Only in Mobile Mode) */}
        {isMobilePreview && (
          <div className="w-full bg-slate-950 px-6 py-2 flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800">
            <span className="font-semibold text-white">19:42</span>
            <div className="w-24 h-4 bg-slate-900 rounded-full mx-auto"></div>
            <span>100% 5G</span>
          </div>
        )}

        {/* Top Header */}
        <Header
          currentTime={currentTime}
          isSimulatedTime={isSimulatedTime}
          onToggleTimeMode={() => {
            setIsSimulatedTime((prev) => !prev);
            if (isSimulatedTime) {
              setCurrentTime(new Date());
            } else {
              setCurrentTime(new Date(2026, 8, 27, 19, 42));
            }
          }}
          soundEnabled={soundEnabled}
          onToggleSound={handleToggleSound}
          isMobilePreview={isMobilePreview}
          onToggleMobilePreview={() => setIsMobilePreview((prev) => !prev)}
          showVirtualRemote={showVirtualRemote}
          onToggleVirtualRemote={() => setShowVirtualRemote((prev) => !prev)}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenCreator={() => setIsCreatorOpen(true)}
          onOpenApkDownload={() => setIsApkGuideOpen(true)}
        />

        {/* Content Body: Left Sidebar + Main TV Canvas */}
        <div className="flex-1 flex flex-col md:flex-row px-4 sm:px-6 pb-6 gap-5">
          {/* Left Navigation Sidebar */}
          <Sidebar
            activeTab={activeTab}
            onSelectTab={(tab) => {
              setActiveTab(tab);
              if (tab === 'configuracoes') setIsSettingsOpen(true);
              if (tab === 'aplicativos') setIsFavoritesManagerOpen(true);
            }}
            isFocusedZone={focusState.zone === 'sidebar'}
            focusedIndex={focusState.index}
            onFocusChange={(idx) => setFocusState({ zone: 'sidebar', index: idx })}
          />

          {/* Main Content Area */}
          <main className="flex-1 flex flex-col gap-5 min-w-0">
            {/* Top Weather Widget */}
            <WeatherWidget
              weather={weather}
              isFocused={focusState.zone === 'weather'}
              onSelect={() => setIsSettingsOpen(true)}
              onOpenSettings={() => setIsSettingsOpen(true)}
            />

            {/* Favorite Apps Row */}
            <section aria-label="Aplicativos Principais">
              <AppRow
                apps={favoriteApps}
                isFocusedZone={focusState.zone === 'apps'}
                focusedIndex={focusState.index}
                onFocusChange={(idx) => setFocusState({ zone: 'apps', index: idx })}
                onLaunchApp={(app) => setActiveSimulatorApp(app)}
                onOpenAddModal={() => setIsFavoritesManagerOpen(true)}
                onOpenAllApps={() => setIsFavoritesManagerOpen(true)}
                onRemoveApp={handleRemoveApp}
                onMoveApp={handleMoveApp}
              />
            </section>

            {/* HDMI Inputs Row */}
            <section aria-label="Entradas de Vídeo">
              <HdmiRow
                sources={INITIAL_HDMI_SOURCES}
                isFocusedZone={focusState.zone === 'hdmi'}
                focusedIndex={focusState.index}
                onFocusChange={(idx) => setFocusState({ zone: 'hdmi', index: idx })}
                onSelectSource={(source) => setActiveSimulatorHdmi(source)}
              />
            </section>

            {/* Media Posters Recommendations Row */}
            <section aria-label="Filmes e Séries em Destaque">
              <MediaRow
                mediaItems={displayedMedia}
                isFocusedZone={focusState.zone === 'media'}
                focusedIndex={focusState.index}
                onFocusChange={(idx) => setFocusState({ zone: 'media', index: idx })}
                onSelectMedia={(media) => setActiveSimulatorMedia(media)}
              />
            </section>
          </main>
        </div>

        {/* Mobile View Bottom Notch */}
        {isMobilePreview && (
          <div className="w-full bg-slate-950 py-2.5 flex items-center justify-center border-t border-slate-800">
            <div className="w-32 h-1 bg-slate-600 rounded-full"></div>
          </div>
        )}
      </div>

      {/* Floating On-Screen TV Remote Control (for mobile & PC testing) */}
      <VirtualRemote
        isOpen={showVirtualRemote}
        onClose={() => setShowVirtualRemote(false)}
        onDpadUp={() => handleNavigate('up')}
        onDpadDown={() => handleNavigate('down')}
        onDpadLeft={() => handleNavigate('left')}
        onDpadRight={() => handleNavigate('right')}
        onSelectOk={handleSelectOk}
        onBack={handleBack}
        onHome={() => {
          setActiveTab('inicio');
          setFocusState({ zone: 'apps', index: 1 });
        }}
        onMenu={() => setIsSettingsOpen(true)}
      />

      {/* Floating Quick Action button to open Virtual Remote on small screens */}
      {!showVirtualRemote && (
        <button
          onClick={() => setShowVirtualRemote(true)}
          className="fixed bottom-5 right-5 z-40 p-3 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 text-white shadow-[0_0_20px_rgba(6,182,212,0.6)] hover:scale-110 active:scale-95 transition-all cursor-pointer md:hidden"
          title="Abrir Controle TV"
          aria-label="Abrir controle remoto virtual"
        >
          <Tv className="w-5 h-5" />
        </button>
      )}

      {/* Creator Modal ("Criador: Leandro Corrêa") */}
      <CreatorModal
        isOpen={isCreatorOpen}
        onClose={() => setIsCreatorOpen(false)}
        onOpenApkGuide={() => {
          setIsCreatorOpen(false);
          setIsApkGuideOpen(true);
        }}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
        ambientGlow={ambientGlow}
        onToggleAmbientGlow={() => setAmbientGlow((prev) => !prev)}
        oledProtection={oledProtection}
        onToggleOledProtection={() => setOledProtection((prev) => !prev)}
        isSimulatedTime={isSimulatedTime}
        onToggleTimeMode={() => {
          setIsSimulatedTime((prev) => !prev);
          if (isSimulatedTime) {
            setCurrentTime(new Date());
          } else {
            setCurrentTime(new Date(2026, 8, 27, 19, 42));
          }
        }}
        city={weather.city}
        onCityChange={(newCity) => setWeather((prev) => ({ ...prev, city: newCity }))}
        onOpenCreator={() => {
          setIsSettingsOpen(false);
          setIsCreatorOpen(true);
        }}
        onOpenFavoritesManager={() => {
          setIsSettingsOpen(false);
          setIsFavoritesManagerOpen(true);
        }}
        onOpenApkGuide={() => {
          setIsSettingsOpen(false);
          setIsApkGuideOpen(true);
        }}
      />

      {/* Favorites Manager Modal */}
      <FavoritesManagerModal
        isOpen={isFavoritesManagerOpen}
        onClose={() => setIsFavoritesManagerOpen(false)}
        favoriteApps={favoriteApps}
        onAddApp={handleAddApp}
        onRemoveApp={handleRemoveApp}
        onMoveApp={handleMoveApp}
        onResetDefaults={handleResetDefaults}
      />

      {/* APK Installation Guide Modal */}
      <ApkGuideModal
        isOpen={isApkGuideOpen}
        onClose={() => setIsApkGuideOpen(false)}
      />

      {/* App & Media Launch Simulator */}
      <AppSimulatorModal
        app={activeSimulatorApp}
        media={activeSimulatorMedia}
        hdmi={activeSimulatorHdmi}
        onClose={() => {
          setActiveSimulatorApp(null);
          setActiveSimulatorMedia(null);
          setActiveSimulatorHdmi(null);
        }}
      />
    </div>
  );
}
