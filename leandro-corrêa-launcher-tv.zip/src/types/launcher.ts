export interface AppItem {
  id: string;
  name: string;
  category: string;
  iconType: 'flixcine' | 'youtube' | 'tcl' | 'more' | 'add' | 'netflix' | 'prime' | 'disney' | 'max' | 'spotify' | 'twitch' | 'custom';
  iconColor?: string;
  accentBg?: string;
  badge?: string;
  url?: string;
  isCustom?: boolean;
}

export interface MediaItem {
  id: string;
  title: string;
  type: 'Filme' | 'Série';
  posterUrl: string;
  backdropUrl?: string;
  year?: string;
  rating?: string;
  synopsis?: string;
  genre?: string;
}

export interface HdmiSource {
  id: string;
  name: string;
  label: string;
  active: boolean;
  connectedDevice?: string;
}

export interface WeatherData {
  city: string;
  state: string;
  temperature: number;
  condition: string;
  forecast: {
    day: string;
    condition: 'sun' | 'sun-cloud' | 'rain' | 'cloud';
    max: number;
    min: number;
  }[];
  humidity: number;
  windSpeed: number;
  uvIndex: number;
  uvDescription: string;
  pressure: number;
  quote: string;
}

export type FocusZone = 'sidebar' | 'weather' | 'apps' | 'hdmi' | 'media';

export interface FocusState {
  zone: FocusZone;
  index: number;
}
